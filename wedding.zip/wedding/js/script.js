$(document).ready(function(){
    $('.venobox').venobox(); 
});
$('.slick_photo').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: false,
        dots: false,
    });